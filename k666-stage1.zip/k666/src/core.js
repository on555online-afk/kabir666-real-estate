import 'react-native-url-polyfill/auto';
import React,{createContext,useContext,useState} from 'react';
import {View,Text} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import {createClient} from '@supabase/supabase-js';
export const supabase=createClient(process.env.EXPO_PUBLIC_SUPABASE_URL||'http://invalid',process.env.EXPO_PUBLIC_SUPABASE_ANON_KEY||'x',{auth:{storage:AsyncStorage,autoRefreshToken:true,persistSession:true,detectSessionInUrl:false}});
export const PHONE='9893022696',WA='https://wa.me/919893022696';
export const C={green:'#0B5D3B',dark:'#073D27',gold:'#C9A227',bg:'#F7F8F5',white:'#fff',ink:'#1B2A22',mute:'#6B7A72',line:'#E1E6E2',err:'#B3261E'};
const T={en:{buy:'Buy',rent:'Rent',sell:'Sell',commercial:'Commercial',residential:'Residential',plot:'Plot',search:'Search',saved:'Saved',profile:'Profile',home:'Home',city:'City',locality:'Locality',minP:'Min price ₹',maxP:'Max price ₹',beds:'Bedrooms',find:'Find properties',none:'No properties found.',call:'Call',wa:'WhatsApp',enq:'Send enquiry',emi:'EMI calculator',login:'Login',signup:'Sign up',logout:'Logout',email:'Email',pass:'Password (min 8)',tag:'Delhi NCR properties',lang:'हिंदी',name:'Your name',phone:'Phone',msg:'Message',sent:'Enquiry sent.',needLogin:'Please login first.',amt:'Loan amount ₹',rate:'Interest % per year',yrs:'Years',emiIs:'Monthly EMI',err:'Something went wrong. Try again.',cfg:'Backend not configured. See README.'},
hi:{buy:'खरीदें',rent:'किराया',sell:'बेचें',commercial:'कमर्शियल',residential:'रिहायशी',plot:'प्लॉट',search:'खोजें',saved:'पसंदीदा',profile:'प्रोफ़ाइल',home:'होम',city:'शहर',locality:'इलाका',minP:'न्यूनतम कीमत ₹',maxP:'अधिकतम कीमत ₹',beds:'बेडरूम',find:'प्रॉपर्टी खोजें',none:'कोई प्रॉपर्टी नहीं मिली।',call:'कॉल करें',wa:'व्हाट्सऐप',enq:'पूछताछ भेजें',emi:'EMI कैलकुलेटर',login:'लॉगिन',signup:'साइन अप',logout:'लॉगआउट',email:'ईमेल',pass:'पासवर्ड (कम से कम 8)',tag:'दिल्ली NCR प्रॉपर्टी',lang:'English',name:'आपका नाम',phone:'फ़ोन',msg:'संदेश',sent:'पूछताछ भेज दी गई।',needLogin:'पहले लॉगिन करें।',amt:'लोन राशि ₹',rate:'ब्याज % प्रति वर्ष',yrs:'वर्ष',emiIs:'मासिक EMI',err:'कुछ गड़बड़ हुई। फिर कोशिश करें।',cfg:'बैकएंड सेट नहीं है। README देखें।'}};
const L=createContext();
export const LangProvider=({children})=>{const[l,setL]=useState('en');return <L.Provider value={{l,t:k=>T[l][k]||k,toggle:()=>setL(l==='en'?'hi':'en')}}>{children}</L.Provider>};
export const useLang=()=>useContext(L);
export const inr=n=>'₹'+Number(n).toLocaleString('en-IN');
export const Logo=({size=56})=>{const w=size*.16;return <View style={{width:size,height:size,borderRadius:size*.22,backgroundColor:C.green,borderWidth:2,borderColor:C.gold,alignItems:'center',justifyContent:'flex-end',paddingBottom:size*.14,flexDirection:'row',gap:w*.4,paddingHorizontal:size*.18}}>
{[.5,.7,.55].map((h,i)=><View key={i} style={{flex:1,height:size*h,backgroundColor:i===1?C.gold:C.white,borderTopLeftRadius:2,borderTopRightRadius:2}}/>)}</View>};
