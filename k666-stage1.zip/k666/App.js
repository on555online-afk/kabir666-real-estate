import React,{useEffect,useState} from 'react';
import {View,Text,TextInput,TouchableOpacity,ScrollView,FlatList,ActivityIndicator,Linking,Share,Alert,StyleSheet as S} from 'react-native';
import {NavigationContainer} from '@react-navigation/native';
import {createNativeStackNavigator} from '@react-navigation/native-stack';
import {createBottomTabNavigator} from '@react-navigation/bottom-tabs';
import {StatusBar} from 'expo-status-bar';
import {supabase,C,PHONE,WA,LangProvider,useLang,inr,Logo} from './src/core';

const Btn=({title,onPress,gold,style})=><TouchableOpacity onPress={onPress} style={[st.btn,gold&&{backgroundColor:C.gold},style]}><Text style={[st.btnT,gold&&{color:C.dark}]}>{title}</Text></TouchableOpacity>;
const In=p=><TextInput placeholderTextColor={C.mute} {...p} style={st.in}/>;

function Home({navigation}){const{t,toggle}=useLang();
const cats=[['buy',{purpose:'sale'}],['rent',{purpose:'rent'}],['sell','sell'],['commercial',{category:'commercial'}],['residential',{category:'residential'}],['plot',{category:'plot'}]];
return <ScrollView style={{flex:1,backgroundColor:C.bg}}>
<View style={st.hero}><View style={{flexDirection:'row',justifyContent:'space-between'}}><Logo/><TouchableOpacity onPress={toggle}><Text style={{color:C.gold,fontWeight:'700'}}>{t('lang')}</Text></TouchableOpacity></View>
<Text style={st.h1}>KABIR666{'\n'}REAL ESTATE</Text><Text style={{color:'#cfe5da'}}>{t('tag')}</Text></View>
<View style={st.grid}>{cats.map(([k,f])=><TouchableOpacity key={k} style={st.cat} onPress={()=>f==='sell'?Alert.alert(t('sell'),'Stage 2'):navigation.navigate('Search',{preset:f,ts:Date.now()})}><Text style={st.catT}>{t(k)}</Text></TouchableOpacity>)}</View>
<View style={{padding:16,gap:10}}><Btn gold title={t('emi')} onPress={()=>navigation.navigate('EMI')}/>
<Btn title={`${t('call')} ${PHONE}`} onPress={()=>Linking.openURL('tel:'+PHONE)}/></View></ScrollView>}

function Card({p,onPress}){return <TouchableOpacity style={st.card} onPress={onPress}><View style={st.ph}><Text style={{color:C.mute}}>{p.property_images?.length?`${p.property_images.length} photo(s)`:'No photo'}</Text></View>
<View style={{padding:12}}><Text style={st.price}>{inr(p.price)}{p.purpose==='rent'?' /mo':''}</Text><Text style={{fontWeight:'700',color:C.ink}}>{p.title}</Text>
<Text style={{color:C.mute}}>{[p.locality,p.city].filter(Boolean).join(', ')} • {p.bedrooms?p.bedrooms+' BHK • ':''}{p.area_sqft||'-'} sq ft</Text></View></TouchableOpacity>}

function Search({route,navigation}){const{t}=useLang();
const[f,setF]=useState({city:'',locality:'',minP:'',maxP:'',beds:''});const[pre,setPre]=useState({});
const[rows,setRows]=useState(null);const[err,setErr]=useState(null);const[busy,setBusy]=useState(false);
useEffect(()=>{if(route.params?.preset){setPre(route.params.preset)}},[route.params?.ts]);
const run=async()=>{setBusy(true);setErr(null);
let q=supabase.from('properties').select('*,property_images(url)').eq('status','approved').order('featured',{ascending:false}).order('created_at',{ascending:false}).limit(50);
if(pre.purpose)q=q.eq('purpose',pre.purpose);if(pre.category)q=q.eq('category',pre.category);
if(f.city.trim())q=q.ilike('city','%'+f.city.trim().replace(/[%,]/g,'')+'%');
if(f.locality.trim())q=q.ilike('locality','%'+f.locality.trim().replace(/[%,]/g,'')+'%');
if(+f.minP)q=q.gte('price',+f.minP);if(+f.maxP)q=q.lte('price',+f.maxP);if(+f.beds)q=q.eq('bedrooms',+f.beds);
const{data,error}=await q;setBusy(false);if(error){setErr(process.env.EXPO_PUBLIC_SUPABASE_URL?t('err'):t('cfg'));setRows([])}else setRows(data)};
useEffect(()=>{run()},[pre]);
return <FlatList style={{backgroundColor:C.bg}} contentContainerStyle={{padding:16,gap:12}} data={rows||[]} keyExtractor={i=>i.id}
ListHeaderComponent={<View style={{gap:8}}><In placeholder={t('city')} value={f.city} onChangeText={v=>setF({...f,city:v})}/><In placeholder={t('locality')} value={f.locality} onChangeText={v=>setF({...f,locality:v})}/>
<View style={{flexDirection:'row',gap:8}}><In style={[st.in,{flex:1}]} keyboardType="numeric" placeholder={t('minP')} value={f.minP} onChangeText={v=>setF({...f,minP:v})}/><In style={[st.in,{flex:1}]} keyboardType="numeric" placeholder={t('maxP')} value={f.maxP} onChangeText={v=>setF({...f,maxP:v})}/></View>
<In keyboardType="numeric" placeholder={t('beds')} value={f.beds} onChangeText={v=>setF({...f,beds:v})}/><Btn title={t('find')} onPress={run}/>
{busy&&<ActivityIndicator color={C.green}/>}{err&&<Text style={{color:C.err}}>{err}</Text>}</View>}
ListEmptyComponent={!busy&&rows&&!err?<Text style={{textAlign:'center',color:C.mute,marginTop:30}}>{t('none')}</Text>:null}
renderItem={({item})=><Card p={item} onPress={()=>navigation.navigate('Details',{p:item})}/>}/>}

function Details({route}){const{t}=useLang();const p=route.params.p;const[n,setN]=useState('');const[ph,setPh]=useState('');const[m,setM]=useState('');
const send=async()=>{const{data:{user}}=await supabase.auth.getUser();if(!user)return Alert.alert(t('needLogin'));
if(n.trim().length<2||!/^[6-9]\d{9}$/.test(ph))return Alert.alert(t('err'),'Name + 10-digit mobile');
const{error}=await supabase.from('enquiries').insert({user_id:user.id,property_id:p.id,name:n.trim(),phone:ph,message:m.trim().slice(0,500)});Alert.alert(error?t('err'):t('sent'))};
const fav=async()=>{const{data:{user}}=await supabase.auth.getUser();if(!user)return Alert.alert(t('needLogin'));
const{error}=await supabase.from('favourites').upsert({user_id:user.id,property_id:p.id});Alert.alert(error?t('err'):'♥')};
return <ScrollView style={{flex:1,backgroundColor:C.bg}} contentContainerStyle={{padding:16,gap:10}}>
<Text style={st.price}>{inr(p.price)}{p.purpose==='rent'?' /mo':''}</Text><Text style={{fontSize:20,fontWeight:'700',color:C.ink}}>{p.title}</Text>
<Text style={{color:C.mute}}>{[p.locality,p.city].filter(Boolean).join(', ')} • {p.area_sqft||'-'} sq ft</Text>{!!p.description&&<Text style={{color:C.ink}}>{p.description}</Text>}
{!!p.amenities?.length&&<Text style={{color:C.ink}}>{p.amenities.join(' • ')}</Text>}
<View style={{flexDirection:'row',gap:8}}><Btn style={{flex:1}} title={t('call')} onPress={()=>Linking.openURL('tel:'+PHONE)}/><Btn style={{flex:1}} gold title={t('wa')} onPress={()=>Linking.openURL(WA+'?text='+encodeURIComponent('Hi, I am interested in: '+p.title))}/></View>
<View style={{flexDirection:'row',gap:8}}><Btn style={{flex:1}} title="♡" onPress={fav}/><Btn style={{flex:1}} title="Share" onPress={()=>Share.share({message:`${p.title} - ${inr(p.price)}. Call ${PHONE}`})}/></View>
<In placeholder={t('name')} value={n} onChangeText={setN}/><In placeholder={t('phone')} keyboardType="phone-pad" maxLength={10} value={ph} onChangeText={setPh}/><In placeholder={t('msg')} multiline value={m} onChangeText={setM}/><Btn title={t('enq')} onPress={send}/></ScrollView>}

function EMI(){const{t}=useLang();const[a,setA]=useState('');const[r,setR]=useState('');const[y,setY]=useState('');
const P=+a,i=+r/1200,n=+y*12;const e=P>0&&n>0?(i===0?P/n:P*i*Math.pow(1+i,n)/(Math.pow(1+i,n)-1)):null;
return <View style={{flex:1,padding:16,gap:10,backgroundColor:C.bg}}><In keyboardType="numeric" placeholder={t('amt')} value={a} onChangeText={setA}/><In keyboardType="numeric" placeholder={t('rate')} value={r} onChangeText={setR}/><In keyboardType="numeric" placeholder={t('yrs')} value={y} onChangeText={setY}/>
{e&&isFinite(e)&&<Text style={st.price}>{t('emiIs')}: {inr(Math.round(e))}</Text>}</View>}

function Account(){const{t}=useLang();const[u,setU]=useState(null);const[em,setEm]=useState('');const[pw,setPw]=useState('');const[busy,setBusy]=useState(false);
useEffect(()=>{supabase.auth.getUser().then(({data})=>setU(data.user));const{data:s}=supabase.auth.onAuthStateChange((_,x)=>setU(x?.user||null));return()=>s.subscription.unsubscribe()},[]);
const go=async mode=>{if(!/^\S+@\S+\.\S+$/.test(em)||pw.length<8)return Alert.alert(t('err'),t('pass'));setBusy(true);
const{error}=mode==='in'?await supabase.auth.signInWithPassword({email:em,password:pw}):await supabase.auth.signUp({email:em,password:pw});setBusy(false);if(error)Alert.alert(t('err'),error.message)};
if(u)return <View style={{flex:1,padding:16,gap:10,backgroundColor:C.bg}}><Text style={{color:C.ink}}>{u.email}</Text><Btn title={t('logout')} onPress={()=>supabase.auth.signOut()}/></View>;
return <View style={{flex:1,padding:16,gap:10,backgroundColor:C.bg}}><In autoCapitalize="none" keyboardType="email-address" placeholder={t('email')} value={em} onChangeText={setEm}/><In secureTextEntry placeholder={t('pass')} value={pw} onChangeText={setPw}/>
{busy?<ActivityIndicator color={C.green}/>:<><Btn title={t('login')} onPress={()=>go('in')}/><Btn gold title={t('signup')} onPress={()=>go('up')}/></>}</View>}

const Tab=createBottomTabNavigator(),Stack=createNativeStackNavigator();
const hdr={headerStyle:{backgroundColor:C.green},headerTintColor:'#fff'};
function Tabs(){const{t}=useLang();return <Tab.Navigator screenOptions={{...hdr,tabBarActiveTintColor:C.green}}>
<Tab.Screen name="Home" component={Home} options={{title:t('home'),headerShown:false}}/><Tab.Screen name="Search" component={Search} options={{title:t('search')}}/><Tab.Screen name="Account" component={Account} options={{title:t('profile')}}/></Tab.Navigator>}
export default function App(){return <LangProvider><StatusBar style="light"/><NavigationContainer><Stack.Navigator screenOptions={hdr}>
<Stack.Screen name="Tabs" component={Tabs} options={{headerShown:false}}/><Stack.Screen name="Details" component={Details}/><Stack.Screen name="EMI" component={EMI}/></Stack.Navigator></NavigationContainer></LangProvider>}
const st=S.create({hero:{backgroundColor:C.green,padding:20,paddingTop:48,gap:10,borderBottomLeftRadius:24,borderBottomRightRadius:24},h1:{color:'#fff',fontSize:28,fontWeight:'800'},
grid:{flexDirection:'row',flexWrap:'wrap',padding:12,gap:10,justifyContent:'center'},cat:{width:'30%',aspectRatio:1,backgroundColor:C.white,borderRadius:14,borderWidth:1,borderColor:C.gold,alignItems:'center',justifyContent:'center'},catT:{color:C.green,fontWeight:'700'},
btn:{backgroundColor:C.green,padding:14,borderRadius:12,alignItems:'center'},btnT:{color:'#fff',fontWeight:'700'},in:{backgroundColor:C.white,borderWidth:1,borderColor:C.line,borderRadius:10,padding:12,color:C.ink},
card:{backgroundColor:C.white,borderRadius:14,borderWidth:1,borderColor:C.line,overflow:'hidden'},ph:{height:110,backgroundColor:'#E8EFEA',alignItems:'center',justifyContent:'center'},price:{fontSize:20,fontWeight:'800',color:C.green}});
