# KABIR666 REAL ESTATE (Stage 1)
1. Create free project at supabase.com -> SQL Editor -> paste supabase/schema.sql -> Run.
2. Copy .env.example to .env, fill URL + anon key (Project Settings -> API). Never use the service_role key in the app.
3. npm install && npx expo install --fix && npx expo start  (scan QR in Expo Go)
4. Make yourself admin: SQL Editor -> update profiles set role='admin' where id='<your user id>';
5. APK: npm i -g eas-cli && eas login && eas build:configure && eas build -p android --profile preview  (APK)
   Play Store: eas build -p android --profile production (AAB)
